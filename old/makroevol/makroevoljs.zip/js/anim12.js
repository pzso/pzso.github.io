(function($) {
    $(document).ready(function() {
	
	$('#anim12').scianimator({
	    'images': ['anim12/anim121.png', 'anim12/anim122.png', 'anim12/anim123.png', 'anim12/anim124.png', 'anim12/anim125.png', 'anim12/anim126.png', 'anim12/anim127.png', 'anim12/anim128.png', 'anim12/anim129.png', 'anim12/anim1210.png', 'anim12/anim1211.png', 'anim12/anim1212.png', 'anim12/anim1213.png', 'anim12/anim1214.png', 'anim12/anim1215.png', 'anim12/anim1216.png', 'anim12/anim1217.png', 'anim12/anim1218.png', 'anim12/anim1219.png', 'anim12/anim1220.png', 'anim12/anim1221.png', 'anim12/anim1222.png', 'anim12/anim1223.png', 'anim12/anim1224.png', 'anim12/anim1225.png', 'anim12/anim1226.png', 'anim12/anim1227.png', 'anim12/anim1228.png', 'anim12/anim1229.png', 'anim12/anim1230.png', 'anim12/anim1231.png', 'anim12/anim1232.png', 'anim12/anim1233.png', 'anim12/anim1234.png', 'anim12/anim1235.png', 'anim12/anim1236.png', 'anim12/anim1237.png', 'anim12/anim1238.png', 'anim12/anim1239.png', 'anim12/anim1240.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
