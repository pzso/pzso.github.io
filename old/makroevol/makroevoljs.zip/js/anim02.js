(function($) {
    $(document).ready(function() {
	
	$('#anim02').scianimator({
	    'images': ['anim02/anim021.png', 'anim02/anim022.png', 'anim02/anim023.png', 'anim02/anim024.png', 'anim02/anim025.png', 'anim02/anim026.png', 'anim02/anim027.png', 'anim02/anim028.png', 'anim02/anim029.png', 'anim02/anim0210.png', 'anim02/anim0211.png', 'anim02/anim0212.png', 'anim02/anim0213.png', 'anim02/anim0214.png', 'anim02/anim0215.png', 'anim02/anim0216.png', 'anim02/anim0217.png', 'anim02/anim0218.png', 'anim02/anim0219.png', 'anim02/anim0220.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
