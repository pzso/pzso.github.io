(function($) {
    $(document).ready(function() {
	
	$('#anim14').scianimator({
	    'images': ['anim14/anim141.png', 'anim14/anim142.png', 'anim14/anim143.png', 'anim14/anim144.png', 'anim14/anim145.png', 'anim14/anim146.png', 'anim14/anim147.png', 'anim14/anim148.png', 'anim14/anim149.png', 'anim14/anim1410.png', 'anim14/anim1411.png', 'anim14/anim1412.png', 'anim14/anim1413.png', 'anim14/anim1414.png', 'anim14/anim1415.png', 'anim14/anim1416.png', 'anim14/anim1417.png', 'anim14/anim1418.png', 'anim14/anim1419.png', 'anim14/anim1420.png', 'anim14/anim1421.png', 'anim14/anim1422.png', 'anim14/anim1423.png', 'anim14/anim1424.png', 'anim14/anim1425.png', 'anim14/anim1426.png', 'anim14/anim1427.png', 'anim14/anim1428.png', 'anim14/anim1429.png', 'anim14/anim1430.png', 'anim14/anim1431.png', 'anim14/anim1432.png', 'anim14/anim1433.png', 'anim14/anim1434.png', 'anim14/anim1435.png', 'anim14/anim1436.png', 'anim14/anim1437.png', 'anim14/anim1438.png', 'anim14/anim1439.png', 'anim14/anim1440.png', 'anim14/anim1441.png', 'anim14/anim1442.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
