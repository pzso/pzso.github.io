(function($) {
    $(document).ready(function() {
	
	$('#anim15').scianimator({
	    'images': ['anim15/anim151.png', 'anim15/anim152.png', 'anim15/anim153.png', 'anim15/anim154.png', 'anim15/anim155.png', 'anim15/anim156.png', 'anim15/anim157.png', 'anim15/anim158.png', 'anim15/anim159.png', 'anim15/anim1510.png', 'anim15/anim1511.png', 'anim15/anim1512.png', 'anim15/anim1513.png', 'anim15/anim1514.png', 'anim15/anim1515.png', 'anim15/anim1516.png', 'anim15/anim1517.png', 'anim15/anim1518.png', 'anim15/anim1519.png', 'anim15/anim1520.png', 'anim15/anim1521.png', 'anim15/anim1522.png', 'anim15/anim1523.png', 'anim15/anim1524.png', 'anim15/anim1525.png', 'anim15/anim1526.png', 'anim15/anim1527.png', 'anim15/anim1528.png', 'anim15/anim1529.png', 'anim15/anim1530.png', 'anim15/anim1531.png', 'anim15/anim1532.png', 'anim15/anim1533.png', 'anim15/anim1534.png', 'anim15/anim1535.png', 'anim15/anim1536.png', 'anim15/anim1537.png', 'anim15/anim1538.png', 'anim15/anim1539.png', 'anim15/anim1540.png', 'anim15/anim1541.png', 'anim15/anim1542.png', 'anim15/anim1543.png', 'anim15/anim1544.png', 'anim15/anim1545.png', 'anim15/anim1546.png', 'anim15/anim1547.png', 'anim15/anim1548.png', 'anim15/anim1549.png', 'anim15/anim1550.png', 'anim15/anim1551.png', 'anim15/anim1552.png', 'anim15/anim1553.png', 'anim15/anim1554.png', 'anim15/anim1555.png', 'anim15/anim1556.png', 'anim15/anim1557.png', 'anim15/anim1558.png', 'anim15/anim1559.png', 'anim15/anim1560.png', 'anim15/anim1561.png', 'anim15/anim1562.png', 'anim15/anim1563.png', 'anim15/anim1564.png', 'anim15/anim1565.png', 'anim15/anim1566.png', 'anim15/anim1567.png', 'anim15/anim1568.png', 'anim15/anim1569.png', 'anim15/anim1570.png', 'anim15/anim1571.png', 'anim15/anim1572.png', 'anim15/anim1573.png', 'anim15/anim1574.png', 'anim15/anim1575.png', 'anim15/anim1576.png', 'anim15/anim1577.png', 'anim15/anim1578.png', 'anim15/anim1579.png', 'anim15/anim1580.png', 'anim15/anim1581.png', 'anim15/anim1582.png', 'anim15/anim1583.png', 'anim15/anim1584.png', 'anim15/anim1585.png', 'anim15/anim1586.png', 'anim15/anim1587.png', 'anim15/anim1588.png', 'anim15/anim1589.png', 'anim15/anim1590.png', 'anim15/anim1591.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
