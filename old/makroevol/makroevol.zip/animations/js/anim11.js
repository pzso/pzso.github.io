(function($) {
    $(document).ready(function() {
	
	$('#anim11').scianimator({
	    'images': ['anim11/anim111.png', 'anim11/anim112.png', 'anim11/anim113.png', 'anim11/anim114.png', 'anim11/anim115.png', 'anim11/anim116.png', 'anim11/anim117.png', 'anim11/anim118.png', 'anim11/anim119.png', 'anim11/anim1110.png', 'anim11/anim1111.png', 'anim11/anim1112.png', 'anim11/anim1113.png', 'anim11/anim1114.png', 'anim11/anim1115.png', 'anim11/anim1116.png', 'anim11/anim1117.png', 'anim11/anim1118.png', 'anim11/anim1119.png', 'anim11/anim1120.png', 'anim11/anim1121.png', 'anim11/anim1122.png', 'anim11/anim1123.png', 'anim11/anim1124.png', 'anim11/anim1125.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
