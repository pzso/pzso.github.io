(function($) {
    $(document).ready(function() {
	
	$('#anim01').scianimator({
	    'images': ['anim01/anim011.png', 'anim01/anim012.png', 'anim01/anim013.png', 'anim01/anim014.png', 'anim01/anim015.png', 'anim01/anim016.png', 'anim01/anim017.png', 'anim01/anim018.png', 'anim01/anim019.png', 'anim01/anim0110.png', 'anim01/anim0111.png', 'anim01/anim0112.png', 'anim01/anim0113.png', 'anim01/anim0114.png', 'anim01/anim0115.png', 'anim01/anim0116.png', 'anim01/anim0117.png', 'anim01/anim0118.png', 'anim01/anim0119.png', 'anim01/anim0120.png', 'anim01/anim0121.png', 'anim01/anim0122.png', 'anim01/anim0123.png', 'anim01/anim0124.png', 'anim01/anim0125.png', 'anim01/anim0126.png', 'anim01/anim0127.png', 'anim01/anim0128.png', 'anim01/anim0129.png', 'anim01/anim0130.png', 'anim01/anim0131.png', 'anim01/anim0132.png', 'anim01/anim0133.png', 'anim01/anim0134.png', 'anim01/anim0135.png', 'anim01/anim0136.png', 'anim01/anim0137.png', 'anim01/anim0138.png', 'anim01/anim0139.png', 'anim01/anim0140.png', 'anim01/anim0141.png', 'anim01/anim0142.png', 'anim01/anim0143.png', 'anim01/anim0144.png', 'anim01/anim0145.png', 'anim01/anim0146.png', 'anim01/anim0147.png', 'anim01/anim0148.png', 'anim01/anim0149.png', 'anim01/anim0150.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
