(function($) {
    $(document).ready(function() {
	
	$('#anim06').scianimator({
	    'images': ['anim06/anim061.png', 'anim06/anim062.png', 'anim06/anim063.png', 'anim06/anim064.png', 'anim06/anim065.png', 'anim06/anim066.png', 'anim06/anim067.png', 'anim06/anim068.png', 'anim06/anim069.png', 'anim06/anim0610.png', 'anim06/anim0611.png', 'anim06/anim0612.png', 'anim06/anim0613.png', 'anim06/anim0614.png', 'anim06/anim0615.png', 'anim06/anim0616.png', 'anim06/anim0617.png', 'anim06/anim0618.png', 'anim06/anim0619.png', 'anim06/anim0620.png', 'anim06/anim0621.png', 'anim06/anim0622.png', 'anim06/anim0623.png', 'anim06/anim0624.png', 'anim06/anim0625.png', 'anim06/anim0626.png', 'anim06/anim0627.png', 'anim06/anim0628.png', 'anim06/anim0629.png', 'anim06/anim0630.png', 'anim06/anim0631.png', 'anim06/anim0632.png', 'anim06/anim0633.png', 'anim06/anim0634.png', 'anim06/anim0635.png', 'anim06/anim0636.png', 'anim06/anim0637.png', 'anim06/anim0638.png', 'anim06/anim0639.png', 'anim06/anim0640.png', 'anim06/anim0641.png', 'anim06/anim0642.png', 'anim06/anim0643.png', 'anim06/anim0644.png', 'anim06/anim0645.png', 'anim06/anim0646.png', 'anim06/anim0647.png', 'anim06/anim0648.png', 'anim06/anim0649.png', 'anim06/anim0650.png', 'anim06/anim0651.png', 'anim06/anim0652.png', 'anim06/anim0653.png', 'anim06/anim0654.png', 'anim06/anim0655.png', 'anim06/anim0656.png', 'anim06/anim0657.png', 'anim06/anim0658.png', 'anim06/anim0659.png', 'anim06/anim0660.png', 'anim06/anim0661.png', 'anim06/anim0662.png', 'anim06/anim0663.png', 'anim06/anim0664.png', 'anim06/anim0665.png', 'anim06/anim0666.png', 'anim06/anim0667.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
