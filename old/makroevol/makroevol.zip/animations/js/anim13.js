(function($) {
    $(document).ready(function() {
	
	$('#anim13').scianimator({
	    'images': ['anim13/anim131.png', 'anim13/anim132.png', 'anim13/anim133.png', 'anim13/anim134.png', 'anim13/anim135.png', 'anim13/anim136.png', 'anim13/anim137.png', 'anim13/anim138.png', 'anim13/anim139.png', 'anim13/anim1310.png', 'anim13/anim1311.png', 'anim13/anim1312.png', 'anim13/anim1313.png', 'anim13/anim1314.png', 'anim13/anim1315.png', 'anim13/anim1316.png', 'anim13/anim1317.png', 'anim13/anim1318.png', 'anim13/anim1319.png', 'anim13/anim1320.png', 'anim13/anim1321.png', 'anim13/anim1322.png', 'anim13/anim1323.png', 'anim13/anim1324.png', 'anim13/anim1325.png', 'anim13/anim1326.png', 'anim13/anim1327.png', 'anim13/anim1328.png', 'anim13/anim1329.png', 'anim13/anim1330.png', 'anim13/anim1331.png', 'anim13/anim1332.png', 'anim13/anim1333.png', 'anim13/anim1334.png', 'anim13/anim1335.png', 'anim13/anim1336.png', 'anim13/anim1337.png', 'anim13/anim1338.png', 'anim13/anim1339.png', 'anim13/anim1340.png', 'anim13/anim1341.png', 'anim13/anim1342.png', 'anim13/anim1343.png', 'anim13/anim1344.png'],
	    'width': 480,
	    'delay': 50,
	    'loopMode': 'loop',
 'controls': ['first', 'previous', 'play', 'next', 'last', 'loop', 'speed']
	});
    });
})(jQuery);
